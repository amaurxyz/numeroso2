// Variáveis do jogo
let targetEquation = '';
let currentRow = 0;
let maxAttempts = 6;
let gameOver = false;

// Elementos DOM
const gameBoard = document.getElementById('gameBoard');
const equationInput = document.getElementById('equationInput');
const messageElement = document.getElementById('message');
const submitBtn = document.getElementById('submitBtn');
const newGameBtn = document.getElementById('newGameBtn');
const helpBtn = document.getElementById('helpBtn');
const helpModal = document.getElementById('helpModal');
const closeModal = document.querySelector('.close');

// Inicializar o jogo
function initGame() {
    targetEquation = generateEquation();
    currentRow = 0;
    gameOver = false;
    
    // Limpar o tabuleiro
    gameBoard.innerHTML = '';
    
    // Criar as linhas do tabuleiro
    for (let i = 0; i < maxAttempts; i++) {
        const row = document.createElement('div');
        row.className = 'equation-row';
        
        for (let j = 0; j < 8; j++) {
            const cell = document.createElement('div');
            cell.className = 'equation-cell';
            cell.textContent = '';
            row.appendChild(cell);
        }
        
        gameBoard.appendChild(row);
    }
    
    // Limpar mensagens
    messageElement.textContent = '';
    messageElement.className = 'message';
    
    // Focar no input
    equationInput.value = '';
    equationInput.focus();
    
    console.log('Equação secreta:', targetEquation); // Para debug
}

function generateEquation2(){
    let operacao = []
    let numeros = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    let operadores = ["+", "-", "*", "/"];
    let igual = ["="];
    let todasListas = [numeros]

    for (let i=0; i<9; i++){
        let listaSorteada = todasListas[Math.floor(Math.random() * todasListas.length)];
        let itemSorteado = listaEscolhida[Math.floor(Math.random() * listaEscolhida.length)];
        if (i>=1){
            todasListas.push(operadores)
        }
        
    }
}

// Gerar uma equação aleatória válida (com possibilidade de múltiplos operadores)
function generateEquation() {
    const operations = ['+', '-', '*'];
    const numOperators = Math.random() ? 2 : 1; // 30% de chance de ter 2 operadores
    
    let expression = '';
    let result = 0;
    
    if (numOperators === 1) {
        // Equação com um operador
        const num1 = Math.floor(Math.random() * 900);
        const num2 = Math.floor(Math.random() * 900);
        const operation = operations[Math.floor(Math.random() * operations.length)];
        
        switch(operation) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                // Garantir que o resultado não seja negativo
                result = Math.max(num1, num2) - Math.min(num1, num2);
                break;
            case '*':
                result = num1 * num2;
                break;
        }
        
        // Formatar a equação (sempre com o maior número primeiro para subtração)
        if (operation === '-') {
            expression = `${Math.max(num1, num2)}${operation}${Math.min(num1, num2)}`;
        } else {
            expression = `${num1}${operation}${num2}`;
        }
    } else {
        // Equação com dois operadores
        const num1 = Math.floor(Math.random() * 9) + 1;
        const num2 = Math.floor(Math.random() * 9) + 1;
        const num3 = Math.floor(Math.random() * 9) + 1;
        
        const op1 = operations[Math.floor(Math.random() * operations.length)];
        let op2 = operations[Math.floor(Math.random() * operations.length)];
        
        // Garantir que a equação seja válida e não tenha resultado negativo
        let valid = false;
        while (!valid) {
            // Avaliar a expressão
            try {
                const tempResult = eval(`${num1}${op1}${num2}${op2}${num3}`);
                if (tempResult > 0 && Number.isInteger(tempResult)) {
                    result = tempResult;
                    expression = `${num1}${op1}${num2}${op2}${num3}`;
                    valid = true;
                } else {
                    op2 = operations[Math.floor(Math.random() * operations.length)];
                }
            } catch (e) {
                op2 = operations[Math.floor(Math.random() * operations.length)];
            }
        }
    }
    
    return `${expression}=${result}`;
}

// Verificar se a equação digitada é válida
function isValidEquation(equation) {
    // Verificar se está vazia
    if (!equation || equation.length === 0) {
        return false;
    }
    
    // Verificar se tem mais de 8 caracteres
    if (equation.length > 8) {
        return false;
    }
    
    // Verificar formato básico: deve conter pelo menos um operador e um igual
    if (!/[+\-*]/.test(equation) || !equation.includes('=')) {
        return false;
    }
    
    // Verificar se a equação é matematicamente correta
    try {
        // Separar a equação em partes
        const equalIndex = equation.indexOf('=');
        const expression = equation.substring(0, equalIndex);
        const expectedResult = equation.substring(equalIndex + 1);
        
        // Avaliar a expressão
        const actualResult = eval(expression);
        
        // Verificar se o resultado é numérico e corresponde
        return !isNaN(actualResult) && actualResult == expectedResult;
    } catch (e) {
        return false;
    }
}

// Verificar a equação do usuário
function checkEquation() {
    if (gameOver) return;
    
    const equation = equationInput.value.trim();
    
    // Validar a equação
    if (!isValidEquation(equation)) {
        messageElement.textContent = 'Equação inválida! Use o formato: número+operador+número=resultado';
        messageElement.className = 'message error';
        return;
    }
    
    // Preencher a linha atual com a equação
    const currentRowElement = gameBoard.children[currentRow];
    for (let i = 0; i < 8; i++) {
        const cell = currentRowElement.children[i];
        cell.textContent = i < equation.length ? equation[i] : '';
        // Resetar classes e estilos
        cell.className = 'equation-cell';
        cell.style.borderRadius = '0';
        cell.style.marginRight = '0';
    }
    
    // Verificar os caracteres
    checkCharacters(equation, currentRowElement);
    
    // Verificar se o jogador acertou
    if (equation === targetEquation) {
        messageElement.textContent = `Parabéns! Você acertou em ${currentRow + 1} tentativa(s)!`;
        messageElement.className = 'message success';
        gameOver = true;
    } else {
        // Avançar para a próxima linha
        currentRow++;
        
        // Verificar se o jogo acabou
        if (currentRow >= maxAttempts) {
            messageElement.textContent = `Fim de jogo! A equação era: ${targetEquation}`;
            messageElement.className = 'message error';
            gameOver = true;
        } else {
            messageElement.textContent = 'Tente novamente!';
            messageElement.className = 'message';
        }
    }
    
    // Limpar o input
    equationInput.value = '';
    equationInput.focus();
}

// Verificar os caracteres da equação
function checkCharacters(equation, rowElement) {
    const targetChars = targetEquation.split('');
    const inputChars = equation.split('');
    const result = Array(8).fill('absent');
    
    // Primeira passada: verificar caracteres corretos na posição correta
    for (let i = 0; i < Math.min(equation.length, 8); i++) {
        if (inputChars[i] === targetChars[i]) {
            result[i] = 'correct';
            // Marcar como usado
            targetChars[i] = null;
        }
    }
    
    // Segunda passada: verificar caracteres presentes mas em posição errada
    for (let i = 0; i < Math.min(equation.length, 8); i++) {
        if (result[i] !== 'correct') {
            const foundIndex = targetChars.indexOf(inputChars[i]);
            if (foundIndex > -1) {
                result[i] = 'present';
                // Marcar como usado
                targetChars[foundIndex] = null;
            }
        }
    }
    
    // Aplicar as classes aos elementos
    for (let i = 0; i < 8; i++) {
        const cell = rowElement.children[i];
        if (result[i] && cell.textContent) {
            cell.classList.add(result[i]);
        }
    }
    
    // Aplicar bordas arredondadas apenas para caracteres corretos nas extremidades
    applyRoundedCorners(rowElement, result);
    
    // Agrupar células de números consecutivos
    groupNumberCells(rowElement, result);
}

// Aplicar bordas arredondadas apenas para caracteres corretos nas extremidades
function applyRoundedCorners(rowElement, result) {
    const cells = rowElement.children;
    
    // Primeiro caractere (se estiver correto)
    if (result[0] === 'correct') {
        cells[0].style.borderTopLeftRadius = '12px';
        cells[0].style.borderBottomLeftRadius = '12px';
    }
    
    // Último caractere (se estiver correto)
    for (let i = 7; i >= 0; i--) {
        if (cells[i].textContent) {
            if (result[i] === 'correct') {
                cells[i].style.borderTopRightRadius = '12px';
                cells[i].style.borderBottomRightRadius = '12px';
            }
            break;
        }
    }
}

// Agrupar visualmente números consecutivos corretos
function groupNumberCells(rowElement, result) {
    let inNumberGroup = false;
    let groupStart = -1;
    
    for (let i = 0; i < 8; i++) {
        const cell = rowElement.children[i];
        const isNumber = cell.textContent && /[0-9]/.test(cell.textContent);
        const isCorrect = result[i] === 'correct';
        
        if (isNumber && isCorrect && !inNumberGroup) {
            // Início de um grupo de números corretos
            inNumberGroup = true;
            groupStart = i;
        } else if ((!isNumber || !isCorrect) && inNumberGroup) {
            // Fim de um grupo de números corretos
            applyGroupStyle(rowElement, groupStart, i - 1);
            inNumberGroup = false;
        }
        
        // Caso especial: último caractere é número correto
        if (i === 7 && inNumberGroup) {
            applyGroupStyle(rowElement, groupStart, i);
        }
    }
}

// Aplicar estilo de grupo a células consecutivas
function applyGroupStyle(rowElement, start, end) {
    if (start === end) return; // Apenas um número, não precisa de agrupamento
    
    for (let i = start; i <= end; i++) {
        const cell = rowElement.children[i];
        
        // Reset de bordas
        cell.style.borderRadius = '0';
        cell.style.marginRight = '0';
        
        // Primeiro do grupo
        if (i === start) {
            cell.style.borderTopLeftRadius = '12px';
            cell.style.borderBottomLeftRadius = '12px';
        }
        
        // Último do grupo
        if (i === end) {
            cell.style.borderTopRightRadius = '12px';
            cell.style.borderBottomRightRadius = '12px';
        }
        
        // Não é o último, remove a margem direita
        if (i < end) {
            cell.style.marginRight = '-2px';
        }
    }
}

// Mostrar modal de ajuda
function showHelp() {
    helpModal.style.display = 'flex';
}

// Fechar modal de ajuda
function closeHelp() {
    helpModal.style.display = 'none';
}

// Event listeners
submitBtn.addEventListener('click', checkEquation);
newGameBtn.addEventListener('click', initGame);
helpBtn.addEventListener('click', showHelp);
closeModal.addEventListener('click', closeHelp);

equationInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        checkEquation();
    }
});

// Fechar modal ao clicar fora dele
window.addEventListener('click', (e) => {
    if (e.target === helpModal) {
        closeHelp();
    }
});

// Iniciar o jogo quando a página carregar
window.addEventListener('load', initGame);