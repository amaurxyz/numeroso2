// Variáveis do jogo
let targetEquation = '';
let currentRow = 0;
let maxAttempts = 6;
let gameOver = false;

// Inicializar o jogo
function initGame() {
    targetEquation = generateEquation();
    currentRow = 0;
    gameOver = false;
    
    // Limpar o tabuleiro
    const gameBoard = document.getElementById('gameBoard');
    gameBoard.innerHTML = '';
    
    // Criar as linhas do tabuleiro
    for (let i = 0; i < maxAttempts; i++) {
        const row = document.createElement('div');
        row.className = 'equation-row';
        
        for (let j = 0; j < 8; j++) {
            const cell = document.createElement('div');
            cell.className = `equation-cell cell-${j}`;
            cell.textContent = '';
            row.appendChild(cell);
        }
        
        gameBoard.appendChild(row);
    }
    
    // Limpar mensagens
    document.getElementById('message').textContent = '';
    document.getElementById('message').className = 'message';
    
    // Focar no input
    document.getElementById('equationInput').value = '';
    document.getElementById('equationInput').focus();
    
    console.log('Equação secreta:', targetEquation); // Para debug
}

// Gerar uma equação aleatória válida
function generateEquation() {
    const operations = ['+', '-', '*'];
    const num1 = Math.floor(Math.random() * 9) + 1; // Número entre 1 e 9
    const num2 = Math.floor(Math.random() * 9) + 1; // Número entre 1 e 9
    const operation = operations[Math.floor(Math.random() * operations.length)];
    
    let result;
    switch(operation) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            // Garantir que o resultado não seja negativo
            result = Math.max(num1, num2) - Math.min(num1, num2);
            break;
        case '*':
            result = num1 * num2;
            break;
    }
    
    // Formatar a equação (sempre com o maior número primeiro para subtração)
    if (operation === '-') {
        return `${Math.max(num1, num2)}${operation}${Math.min(num1, num2)}=${result}`;
    } else {
        return `${num1}${operation}${num2}=${result}`;
    }
}

// Verificar se a equação digitada é válida
function isValidEquation(equation) {
    // Verificar se está vazia
    if (!equation || equation.length === 0) {
        return false;
    }
    
    // Verificar se tem mais de 8 caracteres
    if (equation.length > 8) {
        return false;
    }
    
    // Verificar formato básico: deve conter pelo menos um operador e um igual
    if (!/[+\-*]/.test(equation) || !equation.includes('=')) {
        return false;
    }
    
    // Verificar se a equação é matematicamente correta
    try {
        // Separar a equação em partes
        const equalIndex = equation.indexOf('=');
        const expression = equation.substring(0, equalIndex);
        const expectedResult = equation.substring(equalIndex + 1);
        
        // Avaliar a expressão (cuidado com eval, mas é seguro neste contexto controlado)
        const actualResult = eval(expression);
        
        // Verificar se o resultado é numérico e corresponde
        return !isNaN(actualResult) && actualResult == expectedResult;
    } catch (e) {
        return false;
    }
}

// Verificar a equação do usuário
function checkEquation() {
    if (gameOver) return;
    
    const input = document.getElementById('equationInput');
    const equation = input.value.trim();
    const message = document.getElementById('message');
    
    // Validar a equação
    if (!isValidEquation(equation)) {
        message.textContent = 'Equação inválida! Use o formato: número+operador+número=resultado';
        message.className = 'message error';
        return;
    }
    
    // Preencher a linha atual com a equação
    const currentRowElement = document.getElementById('gameBoard').children[currentRow];
    for (let i = 0; i < 8; i++) {
        const cell = currentRowElement.children[i];
        cell.textContent = i < equation.length ? equation[i] : '';
    }
    
    // Verificar os caracteres
    checkCharacters(equation, currentRowElement);
    
    // Verificar se o jogador acertou
    if (equation === targetEquation) {
        message.textContent = `Parabéns! Você acertou em ${currentRow + 1} tentativa(s)!`;
        message.className = 'message success';
        gameOver = true;
    } else {
        // Avançar para a próxima linha
        currentRow++;
        
        // Verificar se o jogo acabou
        if (currentRow >= maxAttempts) {
            message.textContent = `Fim de jogo! A equação era: ${targetEquation}`;
            message.className = 'message error';
            gameOver = true;
        } else {
            message.textContent = 'Tente novamente!';
            message.className = 'message';
        }
    }
    
    // Limpar o input
    input.value = '';
    input.focus();
}

// Verificar os caracteres da equação
function checkCharacters(equation, rowElement) {
    const targetChars = targetEquation.split('');
    const inputChars = equation.split('');
    const result = Array(8).fill('absent');
    
    // Primeira passada: verificar caracteres corretos na posição correta
    for (let i = 0; i < Math.min(equation.length, 8); i++) {
        if (inputChars[i] === targetChars[i]) {
            result[i] = 'correct';
            // Marcar como usado
            targetChars[i] = null;
        }
    }
    
    // Segunda passada: verificar caracteres presentes mas em posição errada
    for (let i = 0; i < Math.min(equation.length, 8); i++) {
        if (result[i] !== 'correct') {
            const foundIndex = targetChars.indexOf(inputChars[i]);
            if (foundIndex > -1) {
                result[i] = 'present';
                // Marcar como usado
                targetChars[foundIndex] = null;
            }
        }
    }
    
    // Aplicar as classes aos elementos
    for (let i = 0; i < 8; i++) {
        const cell = rowElement.children[i];
        if (result[i] && cell.textContent) {
            cell.classList.add(result[i]);
        }
    }
    
    // Agrupar células de números consecutivos
    groupNumberCells(rowElement);
}

// Agrupar visualmente números consecutivos
function groupNumberCells(rowElement) {
    let inNumberGroup = false;
    let groupStart = -1;
    
    for (let i = 0; i < 8; i++) {
        const cell = rowElement.children[i];
        const isNumber = cell.textContent && /[0-9]/.test(cell.textContent);
        
        if (isNumber && !inNumberGroup) {
            // Início de um grupo de números
            inNumberGroup = true;
            groupStart = i;
        } else if (!isNumber && inNumberGroup) {
            // Fim de um grupo de números
            applyGroupStyle(rowElement, groupStart, i - 1);
            inNumberGroup = false;
        }
        
        // Caso especial: último caractere é número
        if (i === 7 && inNumberGroup) {
            applyGroupStyle(rowElement, groupStart, i);
        }
    }
}

// Aplicar estilo de grupo a células consecutivas
function applyGroupStyle(rowElement, start, end) {
    if (start === end) return; // Apenas um número, não precisa de agrupamento
    
    for (let i = start; i <= end; i++) {
        const cell = rowElement.children[i];
        
        // Reset de bordas
        cell.style.borderRadius = '0';
        cell.style.marginRight = '0';
        
        // Primeiro do grupo
        if (i === start) {
            cell.style.borderTopLeftRadius = '12px';
            cell.style.borderBottomLeftRadius = '12px';
        }
        
        // Último do grupo
        if (i === end) {
            cell.style.borderTopRightRadius = '12px';
            cell.style.borderBottomRightRadius = '12px';
        }
        
        // Não é o último, remove a margem direita
        if (i < end) {
            cell.style.marginRight = '-2px';
        }
    }
}

// Mostrar modal de ajuda
function showHelp() {
    // Criar modal simples
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Como Jogar</h2>
            <p>Descubra a equação matemática secreta em até 6 tentativas.</p>
            <p>✅ Verde: caractere correto na posição correta</p>
            <p>🟨 Amarelo: caractere existe mas em posição errada</p>
            <p>⚫ Cinza: caractere não existe na equação</p>
            <p>Digite equações válidas como "2+3=5", "10-2=8" ou "4*3=12"</p>
            <p>Números consecutivos são agrupados visualmente.</p>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Fechar modal
    modal.querySelector('.close').addEventListener('click', () => {
        document.body.removeChild(modal);
    });
    
    modal.style.display = 'flex';
}

// Event listeners
document.getElementById('submitBtn').addEventListener('click', checkEquation);
document.getElementById('newGameBtn').addEventListener('click', initGame);
document.getElementById('helpBtn').addEventListener('click', showHelp);

document.getElementById('equationInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        checkEquation();
    }
});

// Iniciar o jogo quando a página carregar
window.addEventListener('load', initGame);