// Variáveis do jogo
let targetEquation = '';
let currentRow = 0;
let maxAttempts = 6;
let gameOver = false;
let currentDifficulty = 'easy'; // 'easy', 'normal', 'hard'
let maxLength = 5; // Comprimento máximo baseado na dificuldade

// Tempo
let timeMode = 'none'; // 'none', '5', '10' (strings for data-time)
let timeLimitSeconds = 0; // limite em segundos (0 = sem limite)
let timerInterval = null;
let elapsedTime = 0;
let timerStarted = false;

// Elementos DOM
const gameBoard = document.getElementById('gameBoard');
const equationInput = document.getElementById('equationInput');
const messageElement = document.getElementById('message');
const submitBtn = document.getElementById('submitBtn');
const newGameBtn = document.getElementById('newGameBtn');
const helpBtn = document.getElementById('helpBtn');
const helpModal = document.getElementById('helpModal');
const closeModal = document.querySelector('.close');
const easyBtn = document.getElementById('easyBtn');
const normalBtn = document.getElementById('normalBtn');
const hardBtn = document.getElementById('hardBtn');
const maxLengthDisplay = document.getElementById('maxLengthDisplay');

const timeNoneBtn = document.getElementById('timeNoneBtn');
const time5Btn = document.getElementById('time5Btn');
const time10Btn = document.getElementById('time10Btn');
const timerDisplay = document.getElementById('timerDisplay');

// Inicializar o jogo
function initGame() {
    targetEquation = generateEquation();
    currentRow = 0;
    gameOver = false;
    timerStarted = false;
    elapsedTime = 0;
    clearInterval(timerInterval);
    timerInterval = null;

    // Definir comprimento máximo baseado na dificuldade
    switch(currentDifficulty) {
        case 'easy':
            maxLength = 5; // Agora 5 caracteres para o fácil
            break;
        case 'normal':
            maxLength = 8;
            break;
        case 'hard':
            maxLength = 12;
            break;
    }
    
    // Ajustar maxLength no input e display
    equationInput.placeholder = `Digite uma expressão (até ${maxLength} caracteres)`;
    equationInput.maxLength = maxLength;
    maxLengthDisplay.textContent = maxLength;
    
    // Limpar o tabuleiro
    gameBoard.innerHTML = '';
    
    // Aplicar classe de dificuldade ao body para estilos
    document.body.className = `difficulty-${currentDifficulty}`;
    
    // Criar as linhas do tabuleiro
    for (let i = 0; i < maxAttempts; i++) {
        const row = document.createElement('div');
        row.className = 'equation-row';
        
        for (let j = 0; j < maxLength; j++) {
            const cell = document.createElement('div');
            cell.className = 'equation-cell';
            cell.textContent = '';
            row.appendChild(cell);
        }
        
        gameBoard.appendChild(row);
    }
    
    // Limpar mensagens
    messageElement.textContent = '';
    messageElement.className = 'message';
    
    // Focar no input
    equationInput.value = '';
    equationInput.focus();
    
    // Atualizar timer UI
    updateTimerUI();

    console.log('Equação secreta:', targetEquation); // Para debug
    console.log('Dificuldade:', currentDifficulty); // Para debug
    console.log('Modo de tempo:', timeMode, 'Limite(s):', timeLimitSeconds);
}

// Gerar uma equação aleatória válida (com possibilidade de múltiplos operadores)
function generateEquation() {
    const operations = ['+', '-', '*'];
    let expression = '';
    let result = 0;
    
    switch(currentDifficulty) {
        case 'easy':
            // Equações simples: 1+2=3, 4-1=3, 2*3=6 (máximo 5 caracteres)
            let num1 = Math.floor(Math.random() * 9) + 1;
            let num2 = Math.floor(Math.random() * 9) + 1;
            let operation = operations[Math.floor(Math.random() * operations.length)];
            
            switch(operation) {
                case '+':
                    result = num1 + num2;
                    // Garantir que o resultado tenha apenas 1 dígito para caber em 5 caracteres
                    if (result > 9) {
                        // tentar forçar números menores
                        num1 = Math.floor(Math.random() * 4) + 1;
                        num2 = Math.floor(Math.random() * 4) + 1;
                        result = num1 + num2;
                    }
                    break;
                case '-':
                    // Garantir que o resultado não seja negativo e tenha 1 dígito
                    result = Math.max(num1, num2) - Math.min(num1, num2);
                    if (result > 9) {
                        num1 = Math.floor(Math.random() * 6) + 1;
                        num2 = Math.floor(Math.random() * 6) + 1;
                        result = Math.max(num1, num2) - Math.min(num1, num2);
                    }
                    break;
                case '*':
                    // Multiplicações simples (até 3x3 para caber em 5 caracteres)
                    num1 = Math.min(num1, 3);
                    num2 = Math.min(num2, 3);
                    result = num1 * num2;
                    break;
            }
            
            // Formatar a equação garantindo que caiba em 5 caracteres
            if (operation === '-') {
                expression = `${Math.max(num1, num2)}${operation}${Math.min(num1, num2)}`;
            } else {
                expression = `${num1}${operation}${num2}`;
            }
            
            // Verificar se cabe em 5 caracteres (expressão + = + resultado)
            if (expression.length + 1 + result.toString().length > 5) {
                // Se não couber, forçar uma equação que caiba
                const smallNum1 = Math.floor(Math.random() * 4) + 1;
                const smallNum2 = Math.floor(Math.random() * 4) + 1;
                const smallOp = operations[Math.floor(Math.random() * 2)]; // Apenas + ou -
                
                if (smallOp === '+') {
                    result = smallNum1 + smallNum2;
                } else {
                    result = Math.max(smallNum1, smallNum2) - Math.min(smallNum1, smallNum2);
                }
                
                if (smallOp === '-') {
                    expression = `${Math.max(smallNum1, smallNum2)}${smallOp}${Math.min(smallNum1, smallNum2)}`;
                } else {
                    expression = `${smallNum1}${smallOp}${smallNum2}`;
                }
            }
            break;
            
        case 'normal':
            // Código original do modo normal
            const numOperators = Math.random() > 0.7 ? 2 : 1;
            
            if (numOperators === 1) {
                const n1 = Math.floor(Math.random() * 9) + 1;
                const n2 = Math.floor(Math.random() * 9) + 1;
                const op = operations[Math.floor(Math.random() * operations.length)];
                
                switch(op) {
                    case '+':
                        result = n1 + n2;
                        break;
                    case '-':
                        result = Math.max(n1, n2) - Math.min(n1, n2);
                        break;
                    case '*':
                        result = n1 * n2;
                        break;
                }
                
                if (op === '-') {
                    expression = `${Math.max(n1, n2)}${op}${Math.min(n1, n2)}`;
                } else {
                    expression = `${n1}${op}${n2}`;
                }
            } else {
                let n1 = Math.floor(Math.random() * 9) + 1;
                let n2 = Math.floor(Math.random() * 9) + 1;
                let n3 = Math.floor(Math.random() * 9) + 1;
                
                let op1 = operations[Math.floor(Math.random() * operations.length)];
                let op2 = operations[Math.floor(Math.random() * operations.length)];
                
                let valid = false;
                while (!valid) {
                    try {
                        const tempResult = eval(`${n1}${op1}${n2}${op2}${n3}`);
                        if (tempResult > 0 && Number.isInteger(tempResult)) {
                            result = tempResult;
                            expression = `${n1}${op1}${n2}${op2}${n3}`;
                            valid = true;
                        } else {
                            op2 = operations[Math.floor(Math.random() * operations.length)];
                            n1 = Math.floor(Math.random() * 9) + 1;
                            n2 = Math.floor(Math.random() * 9) + 1;
                            n3 = Math.floor(Math.random() * 9) + 1;
                        }
                    } catch (e) {
                        op2 = operations[Math.floor(Math.random() * operations.length)];
                        n1 = Math.floor(Math.random() * 9) + 1;
                        n2 = Math.floor(Math.random() * 9) + 1;
                        n3 = Math.floor(Math.random() * 9) + 1;
                    }
                }
            }
            break;
            
        case 'hard':
            // Equações complexas com números maiores e mais operadores
            const numOperatorsHard = Math.floor(Math.random() * 2) + 2; // 2 ou 3 operadores
            
            let numbers = [];
            let ops = [];
            
            // Gerar números (podem ter 2 dígitos)
            for (let i = 0; i < numOperatorsHard + 1; i++) {
                numbers.push(Math.floor(Math.random() * 99) + 1);
            }
            
            // Gerar operadores
            for (let i = 0; i < numOperatorsHard; i++) {
                ops.push(operations[Math.floor(Math.random() * operations.length)]);
            }
            
            // Construir expressão e validar
            let validHard = false;
            let attemptsHard = 0;
            while (!validHard && attemptsHard < 60) {
                attemptsHard++;
                expression = '';
                for (let i = 0; i < numbers.length; i++) {
                    expression += numbers[i];
                    if (i < ops.length) expression += ops[i];
                }
                
                try {
                    result = eval(expression);
                    if (result > 0 && Number.isInteger(result) && expression.length <= 11) {
                        validHard = true;
                    } else {
                        // Regerar números se não for válido
                        numbers = [];
                        for (let i = 0; i < numOperatorsHard + 1; i++) {
                            numbers.push(Math.floor(Math.random() * 99) + 1);
                        }
                    }
                } catch (e) {
                    numbers = [];
                    for (let i = 0; i < numOperatorsHard + 1; i++) {
                        numbers.push(Math.floor(Math.random() * 99) + 1);
                    }
                }
            }
            break;
    }
    
    return `${expression}=${result}`;
}

// Verificar se a equação digitada é válida
function isValidEquation(equation, showMessage = true) {
    // Verificar se está vazia
    if (!equation || equation.length === 0) {
        if (showMessage) {
            messageElement.textContent = '';
            messageElement.className = 'message';
        }
        return false;
    }
    
    // Verificar se tem mais caracteres que o permitido
    if (equation.length > maxLength) {
        if (showMessage) {
            messageElement.textContent = `Equação muito longa! Máximo: ${maxLength} caracteres`;
            messageElement.className = 'message error';
        }
        return false;
    }
    
    // Verificar formato básico: deve conter pelo menos um operador e um igual
    if (!/[+\-*]/.test(equation) || !equation.includes('=')) {
        if (showMessage) {
            messageElement.textContent = 'Expressão inválida';
            messageElement.className = 'message error';
        }
        return false;
    }
    
    // Verificar se a equação é matematicamente correta
    try {
        // Separar a equação em partes
        const equalIndex = equation.indexOf('=');
        const expression = equation.substring(0, equalIndex);
        const expectedResult = equation.substring(equalIndex + 1);
        
        // Avaliar a expressão
        if (expression.trim() === '' || expectedResult.trim() === '') {
            if (showMessage) {
                messageElement.textContent = 'Expressão inválida';
                messageElement.className = 'message error';
            }
            return false;
        }
        
        const actualResult = eval(expression);
        
        // Verificar se o resultado é numérico e corresponde
        if (!isNaN(actualResult) && actualResult == expectedResult) {
            // válida
            if (showMessage) {
                messageElement.textContent = '';
                messageElement.className = 'message';
            }
            return true;
        } else {
            if (showMessage) {
                messageElement.textContent = 'Expressão inválida';
                messageElement.className = 'message error';
            }
            return false;
        }
    } catch (e) {
        if (showMessage) {
            messageElement.textContent = 'Expressão inválida! Verifique a sintaxe.';
            messageElement.className = 'message error';
        }
        return false;
    }
}

// Verificar a equação do usuário
function checkEquation() {
    if (gameOver) return;
    
    const equation = equationInput.value.trim();
    
    // Validar a equação
    if (!isValidEquation(equation, true)) {
        return;
    }
    
    // Preencher a linha atual com a equação
    const currentRowElement = gameBoard.children[currentRow];
    for (let i = 0; i < maxLength; i++) {
        const cell = currentRowElement.children[i];
        cell.textContent = i < equation.length ? equation[i] : '';
        // Resetar classes e estilos
        cell.className = 'equation-cell';
        cell.style.borderRadius = '0';
        cell.style.marginRight = '0';
    }
    
    // Verificar os caracteres
    checkCharacters(equation, currentRowElement);
    
    // Verificar se o jogador acertou
    if (equation === targetEquation) {
        messageElement.textContent = `Parabéns! Você acertou em ${currentRow + 1} tentativa(s)!`;
        messageElement.className = 'message success';
        gameOver = true;
        stopTimer();
        return;
    } else {
        // Avançar para a próxima linha
        currentRow++;
        
        // Verificar se o jogo acabou
        if (currentRow >= maxAttempts) {
            messageElement.textContent = `Fim de jogo! A equação era: ${targetEquation}`;
            messageElement.className = 'message error';
            gameOver = true;
            stopTimer();
            return;
        } else {
            // Não mostrar "Tente novamente!" — apenas limpar mensagem (ou manter feedback visual)
            messageElement.textContent = '';
            messageElement.className = 'message';
        }
    }
    
    // Limpar o input
    equationInput.value = '';
    equationInput.focus();
}

// Verificar os caracteres da equação
function checkCharacters(equation, rowElement) {
    const targetChars = targetEquation.split('');
    const inputChars = equation.split('');
    const result = Array(maxLength).fill('absent');
    
    // Primeira passada: verificar caracteres corretos na posição correta
    for (let i = 0; i < Math.min(equation.length, maxLength); i++) {
        if (inputChars[i] === targetChars[i]) {
            result[i] = 'correct';
            // Marcar como usado
            targetChars[i] = null;
        }
    }
    
    // Segunda passada: verificar caracteres presentes mas em posição errada
    for (let i = 0; i < Math.min(equation.length, maxLength); i++) {
        if (result[i] !== 'correct') {
            const foundIndex = targetChars.indexOf(inputChars[i]);
            if (foundIndex > -1) {
                result[i] = 'present';
                // Marcar como usado
                targetChars[foundIndex] = null;
            }
        }
    }
    
    // Aplicar as classes aos elementos
    for (let i = 0; i < maxLength; i++) {
        const cell = rowElement.children[i];
        if (result[i] && cell.textContent) {
            cell.classList.add(result[i]);
        }
    }
    
    // Aplicar bordas arredondadas apenas para caracteres corretos nas extremidades
    applyRoundedCorners(rowElement, result);
    
    // Agrupar células de números consecutivos
    groupNumberCells(rowElement, result);
}

// Aplicar bordas arredondadas apenas para caracteres corretos nas extremidades
function applyRoundedCorners(rowElement, result) {
    const cells = rowElement.children;
    
    // Primeiro caractere (se estiver correto)
    if (result[0] === 'correct') {
        cells[0].style.borderTopLeftRadius = '12px';
        cells[0].style.borderBottomLeftRadius = '12px';
    }
    
    // Último caractere (se estiver correto)
    for (let i = maxLength - 1; i >= 0; i--) {
        if (cells[i].textContent) {
            if (result[i] === 'correct') {
                cells[i].style.borderTopRightRadius = '12px';
                cells[i].style.borderBottomRightRadius = '12px';
            }
            break;
        }
    }
}

// Agrupar visualmente números consecutivos corretos
function groupNumberCells(rowElement, result) {
    let inNumberGroup = false;
    let groupStart = -1;
    
    for (let i = 0; i < maxLength; i++) {
        const cell = rowElement.children[i];
        const isNumber = cell.textContent && /[0-9]/.test(cell.textContent);
        const isCorrect = result[i] === 'correct';
        
        if (isNumber && isCorrect && !inNumberGroup) {
            // Início de um grupo de números corretos
            inNumberGroup = true;
            groupStart = i;
        } else if ((!isNumber || !isCorrect) && inNumberGroup) {
            // Fim de um grupo de números corretos
            applyGroupStyle(rowElement, groupStart, i - 1);
            inNumberGroup = false;
        }
        
        // Caso especial: último caractere é número correto
        if (i === maxLength - 1 && inNumberGroup) {
            applyGroupStyle(rowElement, groupStart, i);
        }
    }
}

// Aplicar estilo de grupo a células consecutivas
function applyGroupStyle(rowElement, start, end) {
    if (start === end) return; // Apenas um número, não precisa de agrupamento
    
    for (let i = start; i <= end; i++) {
        const cell = rowElement.children[i];
        
        // Reset de bordas
        cell.style.borderRadius = '0';
        cell.style.marginRight = '0';
        
        // Primeiro do grupo
        if (i === start) {
            cell.style.borderTopLeftRadius = '12px';
            cell.style.borderBottomLeftRadius = '12px';
        }
        
        // Último do grupo
        if (i === end) {
            cell.style.borderTopRightRadius = '12px';
            cell.style.borderBottomRightRadius = '12px';
        }
        
        // Não é o último, remove a margem direita
        if (i < end) {
            cell.style.marginRight = '-2px';
        }
    }
}

// ********** Funções de Timer **********
function configureTimeMode(mode) {
    timeMode = mode;
    if (mode === 'none') {
        timeLimitSeconds = 0;
        timerDisplay.style.display = 'none';
    } else if (mode === '5') {
        timeLimitSeconds = 5 * 60;
        timerDisplay.style.display = 'block';
    } else if (mode === '10') {
        timeLimitSeconds = 10 * 60;
        timerDisplay.style.display = 'block';
    }
    // reseta timer state
    elapsedTime = 0;
    timerStarted = false;
    clearInterval(timerInterval);
    timerInterval = null;
    updateTimerUI();
    // atualizar botões visuais
    document.querySelectorAll('.time-btn').forEach(btn => btn.classList.remove('active'));
    if (mode === 'none') timeNoneBtn.classList.add('active');
    if (mode === '5') time5Btn.classList.add('active');
    if (mode === '10') time10Btn.classList.add('active');

    // reiniciar o jogo ao mudar o modo de tempo
    initGame();
}

function startTimer() {
    // começa apenas se modo com tempo >= 1 e ainda não iniciou
    if (timerStarted || timeLimitSeconds === 0 || gameOver) return;
    timerStarted = true;
    elapsedTime = 0;
    updateTimerUI();

    timerInterval = setInterval(() => {
        elapsedTime++;
        updateTimerUI();

        // se atingir o limite, game over
        if (timeLimitSeconds > 0 && elapsedTime >= timeLimitSeconds) {
            clearInterval(timerInterval);
            timerInterval = null;
            timerStarted = false;
            // Game over por tempo
            gameOver = true;
            messageElement.textContent = `Tempo esgotado! A equação era: ${targetEquation}`;
            messageElement.className = 'message error';
        }
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    timerStarted = false;
}

function updateTimerUI() {
    if (timeLimitSeconds === 0) {
        timerDisplay.style.display = 'none';
        return;
    }
    timerDisplay.style.display = 'block';
    const remaining = Math.max(0, timeLimitSeconds - elapsedTime);
    const mm = String(Math.floor(remaining / 60)).padStart(2, '0');
    const ss = String(remaining % 60).padStart(2, '0');
    timerDisplay.textContent = `⏱️ ${mm}:${ss}`;
}

// Função para mudar a dificuldade
function changeDifficulty(difficulty) {
    currentDifficulty = difficulty;
    
    // Atualizar botões ativos
    document.querySelectorAll('.difficulty-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-difficulty="${difficulty}"]`).classList.add('active');
    
    // Reiniciar o jogo com a nova dificuldade
    initGame();
}

// Mostrar modal de ajuda
function showHelp() {
    helpModal.style.display = 'flex';
}

// Fechar modal de ajuda
function closeHelp() {
    helpModal.style.display = 'none';
}

// ------------ Event listeners ------------
submitBtn.addEventListener('click', checkEquation);
newGameBtn.addEventListener('click', initGame);
helpBtn.addEventListener('click', showHelp);
closeModal.addEventListener('click', closeHelp);

// Dificuldades
easyBtn.addEventListener('click', () => changeDifficulty('easy'));
normalBtn.addEventListener('click', () => changeDifficulty('normal'));
hardBtn.addEventListener('click', () => changeDifficulty('hard'));

// Time mode buttons
timeNoneBtn.addEventListener('click', () => configureTimeMode('none'));
time5Btn.addEventListener('click', () => configureTimeMode('5'));
time10Btn.addEventListener('click', () => configureTimeMode('10'));

// Enter para enviar
equationInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        checkEquation();
        e.preventDefault();
    }
});

// Input: validar enquanto digita e iniciar timer na primeira digitação
equationInput.addEventListener('input', () => {
    const eq = equationInput.value.trim();

    // iniciar timer ao começar a digitar (apenas se tiver modo com tempo)
    if (timeLimitSeconds > 0 && !timerStarted && !timerInterval && !gameOver) {
        // não inicia por cada tecla; startTimer cuida do não duplicar
        startTimer();
    }

    // validação em tempo real; showMessage = true para exibir "Expressão inválida"
    if (eq.length === 0) {
        messageElement.textContent = '';
        messageElement.className = 'message';
        return;
    }

    // Checa formato básico e armazena erro imediatamente
    isValidEquation(eq, true);
});

// Fechar modal ao clicar fora dele
window.addEventListener('click', (e) => {
    if (e.target === helpModal) {
        closeHelp();
    }
});

// Iniciar o jogo quando a página carregar
window.addEventListener('load', () => {
    // Definir botões de tempo padrão
    configureTimeMode('none');
    initGame();
});